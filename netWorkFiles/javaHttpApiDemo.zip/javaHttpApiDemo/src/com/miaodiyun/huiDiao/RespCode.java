package com.miaodiyun.huiDiao;

/**
 * 响应码常量
 * 
 */
public class RespCode
{
	/**
	 * 成功
	 */
	public static final String SUCCESS = "00000";

	/**
	 * sign错误
	 */
	public static final String SIGN_ERROR = "00006";
}
