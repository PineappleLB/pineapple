package com.miaodiyun.huiDiao.entity;

public class MoNoticeResp
{
	private String respCode;

	public String getRespCode()
	{
		return respCode;
	}

	public void setRespCode(String respCode)
	{
		this.respCode = respCode;
	}
}
